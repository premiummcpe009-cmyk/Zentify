# Zentify

Native Android music-player starter built with Kotlin, Jetpack Compose and AndroidX Media3.

## Current starter features
- Pure-black / dark glass-inspired Compose interface
- Add audio files from device storage using Android's system document picker
- Play and pause local audio with Media3 ExoPlayer
- Search within the imported local library
- GitHub Actions workflow builds a debug APK

## Build from your phone
1. Create a new GitHub repository named `Zentify`.
2. Upload the contents of this folder to the repository root (not the containing folder).
3. Open the repository's **Actions** tab.
4. Enable Actions if GitHub asks.
5. Open **Build Zentify Android APK** and select **Run workflow**, or push a commit to `main`.
6. Open the completed workflow run, scroll to **Artifacts**, and download `Zentify-debug-apk`.
7. Extract the ZIP artifact and install `app-debug.apk`.

## Local build requirements
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 or compatible Gradle wrapper

GitHub Actions uses Gradle 8.9-compatible build tooling through the installed Gradle action / runner.

## Important scope notes
- This starter plays audio files the user selects from their device.
- YouTube Data API can be added for public video metadata (title, channel, thumbnail, duration). It does not provide a general-purpose audio stream.
- Do not extract, proxy, or bypass YouTube playback restrictions. For online playback, integrate a licensed audio provider or a source that explicitly permits streaming.
- Background playback, MediaSession notification controls, playlists persisted across restarts, lyrics, and signed release builds are planned follow-up features.

## Project structure
```text
Zentify/
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/zentify/music/MainActivity.kt
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```
