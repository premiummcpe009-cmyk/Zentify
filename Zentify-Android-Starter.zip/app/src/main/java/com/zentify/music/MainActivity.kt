package com.zentify.music

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private val Black = Color(0xFF050507)
private val Panel = Color(0xFF151519)
private val Glass = Color(0xFF202027)
private val Muted = Color(0xFF96969F)
private val Accent = Color(0xFFB9C8FF)

data class Track(val title: String, val subtitle: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = ExoPlayer.Builder(this).build()
        setContent {
            ZentifyApp(
                player = player,
                onDispose = { player.release() }
            )
        }
    }
}

@Composable
private fun ZentifyApp(player: ExoPlayer, onDispose: () -> Unit) {
    var tracks by remember { mutableStateOf(listOf<Track>()) }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Home") }

    DisposableEffect(Unit) { onDispose { onDispose() } }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                // Keep permission so the selected document remains playable later.
                // SAF providers may or may not support persistable permissions.
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                runCatching {
                    // Content URI access is retained for this app session on providers
                    // that do not offer persistable grants.
                }
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Local audio"
                val track = Track(name.substringAfterLast(':'), "Local audio", uri)
                tracks = tracks + track
                current = track
                player.setMediaItem(MediaItem.fromUri(uri))
                player.prepare()
                player.play()
                playing = true
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Black,
            surface = Panel,
            primary = Accent,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF11131B), Black, Black))
            )
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ZENTIFY", color = Color.White, fontSize = 13.sp,
                            fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                        Text("Your sound, your space.", color = Muted, fontSize = 12.sp)
                    }
                    GlassIcon(Icons.Default.Headphones, "Audio library")
                }
                Spacer(Modifier.height(28.dp))
                Text("Find your", color = Color.White, fontSize = 31.sp,
                    fontWeight = FontWeight.Light)
                Text("frequency.", color = Accent, fontSize = 35.sp,
                    fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(20.dp))

                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(Glass.copy(alpha = .72f))
                        .border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(18.dp))
                        .padding(horizontal = 15.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, null, tint = Muted)
                    Spacer(Modifier.width(10.dp))
                    androidx.compose.foundation.text.BasicTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                        decorationBox = { inner ->
                            Box {
                                if (query.isEmpty()) Text("Search your library", color = Muted, fontSize = 14.sp)
                                inner()
                            }
                        }
                    )
                }

                Spacer(Modifier.height(25.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Your library", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                        Icon(Icons.Default.Add, null, tint = Accent, modifier = Modifier.size(18.dp))
                        Text(" Add music", color = Accent)
                    }
                }

                if (tracks.isEmpty()) {
                    Box(
                        Modifier.fillMaxWidth().padding(top = 8.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF242633), Color(0xFF111116))))
                            .border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(24.dp))
                            .padding(22.dp)
                    ) {
                        Column {
                            Text("A little quiet, for now.", color = Color.White, fontSize = 17.sp,
                                fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(7.dp))
                            Text("Add audio files stored on your device to start your library.",
                                color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(17.dp))
                            Button(onClick = { picker.launch(arrayOf("audio/*")) },
                                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Black),
                                shape = RoundedCornerShape(14.dp)) {
                                Icon(Icons.Default.LibraryMusic, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Choose audio")
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 110.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        items(tracks.filter { it.title.contains(query, true) }) { track ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                    .background(Panel.copy(alpha = .85f))
                                    .clickable {
                                        current = track
                                        player.setMediaItem(MediaItem.fromUri(track.uri))
                                        player.prepare()
                                        player.play()
                                        playing = true
                                    }.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                                    .background(Brush.linearGradient(listOf(Color(0xFF66739A), Color(0xFF252735)))),
                                    contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.MusicNote, null, tint = Color.White)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(track.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(track.subtitle, color = Muted, fontSize = 12.sp)
                                }
                                Icon(Icons.Default.PlayArrow, null, tint = Accent)
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(if (tracks.isEmpty()) 1f else 0f))
                current?.let { track ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF303447), Color(0xFF17171D))))
                            .border(1.dp, Color.White.copy(alpha = .15f), RoundedCornerShape(22.dp))
                            .padding(13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(43.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF59678D)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.GraphicEq, null, tint = Color.White)
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(track.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.Medium)
                            Text("LOCAL AUDIO", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                        }
                        IconButton(onClick = {
                            if (player.isPlaying) { player.pause(); playing = false }
                            else { player.play(); playing = true }
                        }) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                null, tint = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceAround) {
                    NavItem("Home", Icons.Default.Home, tab == "Home") { tab = "Home" }
                    NavItem("Search", Icons.Default.Search, tab == "Search") { tab = "Search" }
                    NavItem("Library", Icons.Default.LibraryMusic, tab == "Library") {
                        tab = "Library"; picker.launch(arrayOf("audio/*"))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String) {
    Box(Modifier.size(42.dp).clip(CircleShape)
        .background(Color.White.copy(alpha = .07f))
        .border(1.dp, Color.White.copy(alpha = .12f), CircleShape),
        contentAlignment = Alignment.Center) {
        Icon(icon, description, tint = Accent, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
        .padding(horizontal = 18.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (selected) Accent else Muted, modifier = Modifier.size(20.dp))
        Text(label, color = if (selected) Accent else Muted, fontSize = 10.sp)
    }
}
